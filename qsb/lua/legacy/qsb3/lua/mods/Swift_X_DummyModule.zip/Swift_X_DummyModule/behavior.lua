--[[
Swift_X_DummyModule/Behavior

Copyright (C) 2021 - 2022 author - All Rights Reserved.

This file is part of Swift. Swift is created by totalwarANGEL.
You may use and modify this file unter the terms of the MIT licence.
(See https://en.wikipedia.org/wiki/MIT_License)
]]

---
-- Fügt Behavior hinzu.
--
-- @set sort=true
--

-- -------------------------------------------------------------------------- --



