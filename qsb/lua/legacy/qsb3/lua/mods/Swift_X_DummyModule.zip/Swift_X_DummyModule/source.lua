--[[
Swift_X_DummyModule/Source

Copyright (C) 2021 - 2022 author - All Rights Reserved.

This file is part of Swift. Swift is created by totalwarANGEL.
You may use and modify this file unter the terms of the MIT licence.
(See https://en.wikipedia.org/wiki/MIT_License)
]]

ModuleDummyModule = {
    Properties = {
        Name = "ModuleDummyModule",
    },

    Global = {},
    Local = {},
    Shared = {
        Text = {},
    }
};

-- Global ------------------------------------------------------------------- --

function ModuleDummyModule.Global:OnGameStart()
end

function ModuleDummyModule.Global:OnEvent(_ID, _Event, ...)
end



-- Local -------------------------------------------------------------------- --

function ModuleDummyModule.Local:OnGameStart()
end

function ModuleDummyModule.Local:OnEvent(_ID, _Event, ...)
end



-- -------------------------------------------------------------------------- --

Swift:RegisterModule(ModuleDummyModule);

